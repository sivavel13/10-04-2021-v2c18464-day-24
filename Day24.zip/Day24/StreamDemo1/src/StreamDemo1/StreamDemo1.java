package StreamDemo1;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class student{
	
	int stdentId;
	String studentName;
	int stuentMarks;
	
	public student(int stdentId, String studentName, int stuentMarks) {
		
		super();
		this.stdentId = stdentId;
		this.studentName = studentName;
		this.stuentMarks = stuentMarks;
	}
}

public class StreamDemo1 {

	public static void main(String[] args) {
		ArrayList<student> Details = new ArrayList<student>();
		Details.add(new student(101, "Tom", 31));		
		Details.add(new student(102, "Jack", 49));
		Details.add(new student(103, "John", 40));
		Details.add(new student(104, "Elon", 100));
		Details.add(new student(105, "Jerry", 90));
		Details.add(new student(106, "Tony", 70));
		Details.add(new student(107, "Mosk", 82));					
		Details.add(new student(108, "Stark", 67));
		Details.add(new student(109, "Godwin", 51));  
		Details.add(new student(110, "yasar", 56));		
		
		List<student> Destination = Details.stream().filter(m -> m.stuentMarks > 80).collect(Collectors.toList());	
		Destination.forEach(i -> System.out.println("Destination students : " + i.studentName));
		
		List<student> FirstClass = Details.stream().filter(m -> m.stuentMarks > 60).filter(m -> m.stuentMarks < 80).collect(Collectors.toList());	
		FirstClass.forEach(i -> System.out.println("FirstClass students : " + i.studentName));
		
		List<student> SecondClass = Details.stream().filter(m -> m.stuentMarks > 50).filter(m -> m.stuentMarks < 60).collect(Collectors.toList());	
		SecondClass.forEach(i -> System.out.println("SecondClass students : " + i.studentName));
		
		List<student> ThirdClass = Details.stream().filter(m -> m.stuentMarks > 35).filter(m -> m.stuentMarks < 50).collect(Collectors.toList());	
		ThirdClass.forEach(i -> System.out.println("ThirdClass students : " + i.studentName));
		
		List<student> LowMarks = Details.stream().filter(m -> m.stuentMarks < 35).collect(Collectors.toList());	
		LowMarks.forEach(i -> System.out.println("Genius students : " + i.studentName));

	}

}


