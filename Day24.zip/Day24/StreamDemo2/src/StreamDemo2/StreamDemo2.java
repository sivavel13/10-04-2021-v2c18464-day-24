package StreamDemo2;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

class employee{
	
	int empId;
	String empName;
	int empAge;
	
	public employee(int empId, String empName, int empAge) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empAge = empAge;
	}	
}

public class StreamDemo2 {

	public static void main(String[] args) {
		
		employee jack = new employee(101, "Jack", 32);
		employee john = new employee(102, "John", 28);
		employee mask = new employee(103, "Mask", 55);
		employee elon = new employee(104, "Elon", 62);
		employee tom = new employee(105, "Tom", 72);
		employee jerry = new employee(106, "Jerry", 88);
		
		ArrayList<employee> EmpDetail = new ArrayList<employee>();
		EmpDetail.add(jack);
		EmpDetail.add(john);
		EmpDetail.add(mask);
		EmpDetail.add(elon);
		EmpDetail.add(tom);
		EmpDetail.add(jerry);
		
		List<String> List1 = EmpDetail.stream().filter(a -> a.empAge > 50).map(a -> a.empName).collect(Collectors.toList());
		System.out.println(List1);
		
		employee empMax = EmpDetail.stream().max((a,b) -> a.empAge > b.empAge  ? 1:-1).get();
		System.out.println("Max age is : " + empMax.empName);
		
		employee empMin = EmpDetail.stream().min((a,b) -> a.empAge > b.empAge  ? 1:-1).get();
		System.out.println("Max age is : " + empMin.empName);
		
		Set<String> List2 = EmpDetail.stream().filter(a -> a.empName.equals(a.empName)).map(a -> a.empName).collect(Collectors.toSet());
		System.out.println(List2);
	
	}
}
